function ret = rdet(a, b)
  ret= a(1) * b(2) - a(2) * b(1);
end
